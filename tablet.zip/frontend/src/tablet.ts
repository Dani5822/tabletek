export interface Tablet {
    id: number;
    Nev: string
    opRendszer: string
    procOrajel: number
    procMagok: number
    kijelzoMeret: number
    kijelzoFelbontas: string
    RAM: number 
    leiras: string
    ar: number
}