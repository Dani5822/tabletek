import { } from 'react'
import "react-bootstrap"

function App() {

  return (
    <>
      <h1>Mobilok...</h1>
      
    </>
  )
}

export default App
